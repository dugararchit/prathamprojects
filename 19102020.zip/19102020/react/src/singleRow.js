import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { AiFillLock } from "react-icons/ai";

class SingleRow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // data: this.props.rowdata,
      // oz: this.props.rowdata.oz,
      // kurztext: this.props.rowdata.kurztext,
      // lv_menge: this.props.rowdata.lv_menge,
      // mengeneinheit: this.props.rowdata.mengeneinheit,
      // ep: this.props.rowdata.ep,
      // festpreis: this.props.festpreis,
      // is_locked: this.props.is_locked,
      // gp: 0,
      // perc: 0,
      rowcolor: "",
    };
  }

  clearingRowColor = () => {
    this.setState({
      rowcolor: "",
    });
  };

  componentDidMount() {
    // [this.props.innerIndex] = this.clearingRowColor;
    // console.log("component did mount in single row");
    // let gp = this.state.ep * this.state.lv_menge;
    // console.log(this.props.totalSumOfGp);
    // let perc = (gp / this.props.totalSumOfGp) * 100;
    // this.setState({
    //   perc: perc,
    //   gp: gp,
    // });
  }

  handleInput = () => {
    this.setState({
      rowcolor: "lightpink",
    });
    //====update that this is currently locked
    console.log(`Locking row id ${this.props.rowdata.id}`);
    fetch(`http://localhost:5000/boq/${this.props.rowdata.id}/1`, { method: "PUT" })
      .then((response) => response.json())
      .then((data) => {
        // console.log(data);
        console.log(`id locked ${this.props.rowdata.id}`);
      });
    this.props.checkChangesInRow(this.props.rowdata.id, this.props.rowdata.parent_boq, 1);
  };

  handleChange = (element, whathaschanged) => {
    this.setState({
      rowcolor: "lightblue",
    });

    let currentValueOfElement = element.currentTarget.textContent.trim();
    let innerIndex = this.props.innerIndex;
    let mainIndex = this.props.mainIndex;
    //setTimeout(() => {
    if (this.props.rowdata[whathaschanged] !== currentValueOfElement) {
      this.props.updateInternalValues(mainIndex, innerIndex, whathaschanged, currentValueOfElement);
    }
    this.props.checkChangesInRow(this.props.rowdata.id, this.props.rowdata.parent_boq);

    // }, 100);
  };

  render() {
    let gp = this.props.rowdata.ep * this.props.rowdata.lv_menge;
    let perc = (gp / this.props.totalSumOfGp) * 100;
    let isContEditable = true;
    if (this.props.rowdata.is_locked.toString() === "1") isContEditable = false;
    // if (this.props.dataCalculated && this.props.dataCalculated === 1) this.setState({ rowColor: "" });
    return (
      <tr className="singleRow" id={this.props.rowdata.id} style={{ backgroundColor: this.state.rowcolor }}>
        <td>
          <div>
            {!isContEditable ? <AiFillLock></AiFillLock> : ""}
            {this.props.rowdata.oz}
          </div>
        </td>
        <td>
          <div>{this.props.rowdata.kurztext}</div>
        </td>
        <td>
          <div onInput={this.handleInput} onBlur={(e) => this.handleChange(e, "lv_menge")} style={{ backgroundColor: "light" }} contentEditable={isContEditable} suppressContentEditableWarning={true} className="lv_menge">
            {this.props.rowdata.lv_menge}
          </div>
        </td>
        <td>
          <div>{this.props.rowdata.mengeneinheit}</div>
        </td>
        <td>
          <div onInput={this.handleInput} onBlur={(e) => this.handleChange(e, "ep")} contentEditable={isContEditable} suppressContentEditableWarning={true} className="ep">
            {this.props.rowdata.ep}
          </div>
        </td>
        <td>
          <div contentEditable={isContEditable} suppressContentEditableWarning={true}>
            {this.props.rowdata.festpreis}
          </div>
        </td>
        <td>
          <div>{gp}</div>
        </td>
        <td>
          <div>{perc.toFixed(2)}%</div>
        </td>
      </tr>
    );
  }
}

export default SingleRow;
