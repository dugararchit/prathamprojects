import { Router } from 'express';
require('../../db/connections');
let DB = require('../../db/dbconnections');
let db = new DB();
const router = Router();
const moment = require('moment');
let socket = require('./index');

router.get('/', async (req, res) => {
  let data = await db.getRecords(
    '',
    '',
    '',
    '',
    '',
    // 'select * from billofquantityparent as p inner join billofquantitychild as c on c.parent_boq=p.id',
    `select bc.id, bc.lv_menge, bc.ep, bc.oz,bc.parent_boq, bc.kurztext, bp.title, bc.mengeneinheit, bc.kurztext, bc.is_locked, bc.position  from billofquantitychild as bc INNER JOIN billofquantityparent as bp on bp.id=bc.parent_boq where bc.level_id=${req.query.levelid} ORDER by parent_boq, position`,
    //`select * from billofquantitychild as bc INNER JOIN billofquantityparent as bp on bp.id=bc.parent_boq where bc.level_id=${req.query.levelid}`
  );
  // console.log(data);
  let mainObj = {};
  console.log(data);
  data.forEach((element) => {
    if (mainObj[element.parent_boq] == undefined) {
      mainObj[element.parent_boq] = {};
      mainObj[element.parent_boq].lv = element.parent_boq;
      mainObj[element.parent_boq].text = element.title;
      mainObj[element.parent_boq].data = [];
      mainObj[element.parent_boq].data.push({
        parent_boq: element.parent_boq,
        oz: element.oz,
        id: element.id,
        kurztext: element.kurztext,
        lv_menge: element.lv_menge,
        mengeneinheit: element.mengeneinheit,
        ep: element.ep,
        is_locked: element.is_locked,
        position: element.position,
      });
    } else {
      mainObj[element.parent_boq].data.push({
        parent_boq: element.parent_boq,
        oz: element.oz,
        id: element.id,
        kurztext: element.kurztext,
        lv_menge: element.lv_menge,
        mengeneinheit: element.mengeneinheit,
        ep: element.ep,
        is_locked: element.is_locked,
        position: element.position,
      });
    }
    // console.log(obj);
  });
  let ArrayData = [];
  for (let tmp in mainObj) {
    // console.log(tmp);
    ArrayData.push(mainObj[tmp]);
  }
  return res.send(ArrayData);
});

router.put('/:id/:locked', async (req, res) => {
  console.log(req.params.id);
  let is_locked = req.params.locked == '1' ? 1 : 0;
  let currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  let stringToSet = `is_locked=${is_locked}, modified_at='${currentTime}'`;
  if (is_locked == 1) {
    stringToSet += `,locked_time='${currentTime}'`;
  } else {
    stringToSet += ',locked_time=NULL';
  }
  let updatedData = await db.updateRecords(
    'billofquantitychild',
    `${stringToSet}`,
    `id=${req.params.id}`,
  );
  console.log(updatedData);
  return res.send(updatedData);
});

router.get('/releasealllock', async (req, res) => {
  console.log(req.params.id);
  let updatedData = await db.updateRecords(
    'billofquantitychild',
    `is_locked=0`,
    `is_locked=1`,
  );
  console.log(updatedData);
  return res.send(updatedData);
});

router.post('/changedData', async (req, res) => {
  let objectDataArray = req.body;
  objectDataArray.forEach((objectData) => {
    objectData.is_locked = objectData.is_locked.toString();
    objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
    const columns = Object.keys(objectData);
    const values = Object.values(objectData);

    db.updateRecords(
      'billofquantitychild',
      `${columns.join(' = ? ,')}`,
      `id='${objectData.id}'`,
      values,
      'multiple',
    );
  });
  return res.send({
    success: true,
  });
});

router.put('/updateSingleRecord', async (req, res) => {
  let objectData = req.body;
  console.log(objectData);
  objectData.is_locked = objectData.is_locked.toString();
  objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
  const columns = Object.keys(objectData);
  const values = Object.values(objectData);

  db.updateRecords(
    'billofquantitychild',
    `${columns.join(' = ? ,')}`,
    `id='${objectData.id}'`,
    values,
    'multiple',
  );

  return res.send({
    success: true,
  });
});

router.post('/insertSingleRecord', async (req, res) => {
  let objectData = req.body;

  // objectData.is_locked = objectData.is_locked.toString();
  // objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
  delete objectData.id;

  console.log(objectData);

  const columns = Object.keys(objectData);
  const values = Object.values(objectData);
  console.log(columns.length, values.length);
  console.log(columns.join(','), values);

  let insertTedRow = await db.insertRecords(
    'billofquantitychild',
    `${columns.join(',')}`,
    ``,
    [[values]],
  );

  console.log(insertTedRow);
  let recordToUpdate = await db.getRecords(
    '',
    '',
    '',
    '',
    '',
    // 'select * from billofquantityparent as p inner join billofquantitychild as c on c.parent_boq=p.id',
    `select * from billofquantitychild where level_id='${objectData.level_id}' and parent_boq='${objectData.parent_boq}' and position >= '${objectData.position}' and id!= '${insertTedRow.insertId}' order by position`,
    //`select * from billofquantitychild as bc INNER JOIN billofquantityparent as bp on bp.id=bc.parent_boq where bc.level_id=${req.query.levelid}`
    // `select @i := ${objectData.position}; update billofquantitychild set position=@i := @i + 1 where level_id='${objectData.level_id}' and parent_boq='${objectData.parent_boq}' and position >= '${objectData.position}' and id!= '${insertTedRow.insertId}'`,
  );

  // update bar set c = (select @i := @i + 1);
  //   console.log(recordToUpdate);

  let newPosition = objectData.position + 1;
  recordToUpdate.forEach((element) => {
    db.updateRecords(
      'billofquantitychild',
      `position='${newPosition}'`,
      `id='${element.id}'`,
      '',
    );
    newPosition = newPosition + 1;
  });

  return res.send({
    success: true,
    insertTedRow,
  });
});

export default router;
