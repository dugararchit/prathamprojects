import 'dotenv/config';
import cors from 'cors';
import express from 'express';

import models from './models';
import routes from './routes';

const app = express();

// * Application-Level Middleware * //

// Third-Party Middleware

app.use(cors());

// Built-In Middleware

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Custom Middleware

app.use((req, res, next) => {
  req.context = {
    models,
    me: models.users[1],
  };
  next();
});

// * Routes * //

// * Start * //

const getApiAndEmit = (socket) => {
  const response = new Date();
  // Emitting a new message. Will be consumed by the client
  socket.emit('FromAPI', response);
};
//===================socket io

let server = app.listen(process.env.PORT, () =>
  console.log(`Example app listening on port ${process.env.PORT}!`),
);

const socketIo = require('socket.io');

const io = socketIo(server);

let interval;

io.on('connection', (socket) => {
  console.log('New client connected', socket.id);
  if (interval) {
    clearInterval(interval);
  }
  interval = setInterval(() => getApiAndEmit(socket), 50000);
  socket.on('disconnect', () => {
    console.log('Client disconnected');
    clearInterval(interval);
  });

  socket.on('locking', (data) => {
    console.log('locking in progress');
    socket.broadcast.emit(`locking_${data.levelId}`, data);
  });

  socket.on('calculator', (data) => {
    socket.broadcast.emit(`calculator_${data.levelId}`);
  });

  socket.on('updatedLockedChanges', (data) => {
    socket.broadcast.emit(
      `updatedLockedChanges_${data.levelId}`,
      data,
    );
  });
  socket.on('updateddata', (data) => {
    socket.broadcast.emit('updatedChangedData', data);
  });
});

app.use('/session', routes.session);
app.use('/users', routes.user);
app.use('/messages', routes.message);
app.use('/boq', routes.boq);
