module.exports = {
    boq: "boq",
    levels: "levels",
    positions: "positions"
}