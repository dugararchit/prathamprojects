import boq from './boq';
export default { boq };
