import { Router } from 'express';
let DB = require('../../db/dbconnections');
let db = new DB();
const router = Router();
const moment = require('moment');
import { positions, levels } from '../../tables';

router.get('/', async (req, res) => {
  let fields = 'p.id, p.lv_menge, p.ep, p.oz, p.level_id, p.kurztext, p.mengeneinheit, p.kurztext, p.is_locked, p.position, l.title as level_title';
  let data = await db.getRecords(`${positions} as p`, fields, `INNER JOIN ${levels} as l on l.id=p.level_id`, `p.boq_id=${req.query.boqid}`, '', `ORDER by p.level_id, p.position`);
  let mainObj = {};
  console.log(data);
  data.forEach((element) => {
    if (mainObj[element.level_id] == undefined) {
      mainObj[element.level_id] = {};
      mainObj[element.level_id].lv = element.level_id;
      mainObj[element.level_id].text = element.level_title;
      mainObj[element.level_id].data = [];
    }
    mainObj[element.level_id].data.push({
      level_id: element.level_id,
      oz: element.oz,
      id: element.id,
      kurztext: element.kurztext,
      lv_menge: element.lv_menge,
      mengeneinheit: element.mengeneinheit,
      ep: element.ep,
      is_locked: element.is_locked,
      position: element.position,
    });
  });
  let arrayData = [];
  for (let tmp in mainObj) {
    arrayData.push(mainObj[tmp]);
  }
  return res.send({
    success: true,
    data: arrayData,
  });
});

router.put('/:id/:locked', async (req, res) => {
  console.log(req.params.id);
  let is_locked = req.params.locked == '1' ? 1 : 0;
  let currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  let stringToSet = `is_locked=${is_locked}, modified_at='${currentTime}'`;
  if (is_locked == 1) {
    stringToSet += `,locked_time='${currentTime}'`;
  } else {
    stringToSet += ',locked_time=NULL';
  }
  let updatedData = await db.updateRecords(positions, `${stringToSet}`, `id=${req.params.id}`);
  console.log(updatedData);
  return res.send(updatedData);
});

router.get('/releasealllock', async (req, res) => {
  console.log(req.params.id);
  let updatedData = await db.updateRecords(positions, `is_locked=0`, `is_locked=1`);
  console.log(updatedData);
  return res.send(updatedData);
});

router.post('/changedData', async (req, res) => {
  let objectDataArray = req.body;
  objectDataArray.forEach((objectData) => {
    objectData.is_locked = objectData.is_locked.toString();
    objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
    const columns = Object.keys(objectData);
    const values = Object.values(objectData);

    db.updateRecords(positions, `${columns.join(' = ? ,')}`, `id='${objectData.id}'`, values, 'multiple');
  });
  return res.send({
    success: true,
  });
});

router.put('/updateSingleRecord', async (req, res) => {
  let objectData = req.body;
  console.log(objectData);
  objectData.is_locked = objectData.is_locked.toString();
  objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
  const columns = Object.keys(objectData);
  const values = Object.values(objectData);
  db.updateRecords(positions, `${columns.join(' = ? ,')}`, `id='${objectData.id}'`, values, 'multiple');
  return res.send({
    success: true,
  });
});

router.post('/insertRecordAndUpdatePositions', async (req, res) => {
  let objectData = req.body;
  delete objectData.id;
  console.log(objectData);
  const columns = Object.keys(objectData);
  const values = Object.values(objectData);
  let insertTedRow = await db.insertRecords(positions, `${columns.join(',')}`, ``, [[values]]);
  let recordToUpdate = await db.getRecords('', '', '', '', '', `select id from ${positions} where boq_id='${objectData.boq_id}' and level_id='${objectData.level_id}' and position >= '${objectData.position}' and id!= '${insertTedRow.insertId}' order by position`);
  let newPosition = objectData.position + 1;
  recordToUpdate.forEach((element) => {
    db.updateRecords(positions, `position='${newPosition}'`, `id='${element.id}'`, '');
    newPosition = newPosition + 1;
  });

  return res.send({
    success: true,
    insertTedRow,
  });
});

export default router;
