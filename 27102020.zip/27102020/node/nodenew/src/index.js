import 'dotenv/config';
import cors from 'cors';
import express from 'express';
import models from './models';
import routes from './routes';
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const getApiAndEmit = (socket) => {
  const response = new Date();
  // Emitting a new message. Will be consumed by the client
  socket.emit('FromAPI', response);
};
//===================socket io

let server = app.listen(process.env.PORT, () =>
  console.log(`App listening on port ${process.env.PORT}!`),
);

const socketIo = require('socket.io');

const io = socketIo(server);

let interval;

io.on('connection', (socket) => {
  console.log('New client connected', socket.id);
  socket.on('disconnect', () => {
    console.log('Client disconnected');
    clearInterval(interval);
  });

  //===when someone request for locking
  socket.on('locking', (data) => {
    console.log('locking in progress');
    socket.broadcast.emit(`locking_${data.boqId}`, data);
  });

  //===when someone request to Recalculate the Data
  socket.on('calculator', (data) => {
    socket.broadcast.emit(`calculator_${data.boqId}`);
  });
  //===when someone request for updates to other level or boq
  socket.on('updatedLockedChanges', (data) => {
    socket.broadcast.emit(
      `updatedLockedChanges_${data.boqId}`,
      data,
    );
  });
});

app.use('/boq', routes.boq);
