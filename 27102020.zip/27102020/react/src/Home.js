import React from "react";
import App from "./App";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
class Home extends React.Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/:id?" render={(props) => <App {...props} />} />
        </Switch>
      </Router>
    );
  }
}

export default Home;
