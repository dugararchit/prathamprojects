import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import TableRows from "./tableRows";
import LvDetails from "./lvDetails";
import OverAllDetails from "./overAllDetails";
import { HOST } from "./config/config";
import { getBoqData, releaseAllLocks } from "./config/services";
import socketIOClient from "socket.io-client";
import Messages from "./messages";
// import { withToastManager } from "react-toast-notifications";
const socket = socketIOClient(HOST);
class App extends React.Component {
  constructor(props) {
    super(props);
    this.buttonCalculatorRef = React.createRef();
    this.messagesReferences = React.createRef();
    this.levelId = 1;
    this.is_touched = [];
    this.state = {
      billOfQuantity: [],
      overallGp: 0,
      update: 0,
    };
  }

  async componentDidMount() {
    console.log(this.props.match.params.id);
    let levelId = this.props.match.params.id || 1;
    this.levelId = levelId;
    getBoqData(levelId)
      .then((data) => {
        this.setState({
          billOfQuantity: data,
        });
      })
      .catch((err) => {
        console.log(err);
      });

    socket.on("calculator_" + this.levelId, () => {
      console.log("staring calculating");
      this.setState({
        update: 1,
      });
    });

    socket.on("updatedLockedChanges_" + this.levelId, ({ rowData }) => {
      console.log(rowData);
      this.buttonCalculatorRef.current.disabled = false;
      let findingChildRef = this[`tableRows_${parseInt(rowData.parent_boq)}`][`singleRowRef_${parseInt(rowData.id)}`];
      console.log(findingChildRef);
      findingChildRef.updateProps(rowData);
    });

    socket.on("locking_" + this.levelId, (data) => {
      console.log(data);
      //=======custom table
      this.buttonCalculatorRef.current.disabled = true;
      let findingChildRef = this[`tableRows_${parseInt(data.rowData.parent_boq)}`][`singleRowRef_${parseInt(data.rowData.id)}`];
      if (data.type === "locked") {
        data.rowData.is_locked = "1";
      }
      findingChildRef.updateProps(data.rowData);
    });
  }

  releaseAllLocks = async () => {
    let releasinglocks = await releaseAllLocks();
    console.log(releasinglocks);
  };

  calculateTotal = () => {
    this.setState({
      update: 1,
    });
    socket.emit("calculator", { levelId: this.levelId });
  };

  handlePaging = (id) => {
    for (let i = 0; i < this.state.billOfQuantity.length; i++) {
      if (i === id) this[`tbody_${i}`].classList.remove("d-none");
      else this[`tbody_${i}`].classList.add("d-none");
    }
  };

  openNewWindow = (id) => {
    const remote = window.require("electron").remote;
    // const { ipcRenderer } = window.require("electron");
    // ipcRenderer.send('asynchronous-message', 'ping')
    const BrowserWindow = remote.BrowserWindow;
    const win = new BrowserWindow({
      height: 600,
      width: 800,
      webPreferences: {
        nodeIntegration: true,
        enableRemoteModule: true,
      },
    });

    win.loadURL("http://localhost:3000/" + id);
    win.once("ready-to-show", () => win.show());
  };

  newRowAdded = (newRow, mainIndex, innerindex) => {
    // console.log("entered in new row index");
    // console.log(newRow, mainIndex, innerindex);
    let newState = this.state.billOfQuantity;

    newState[mainIndex].data.splice(innerindex, 0, newRow);
    for (let i = innerindex + 1; i < newState[mainIndex].data.length; i++) {
      // console.log(newState[mainIndex].data[i]);
      newState[mainIndex].data[i].position = newState[mainIndex].data[i - 1].position + 1;
    }
    this.setState(
      {
        billOfQuantity: newState,
      },
      () => {
        console.log(this.state.billOfQuantity);
      }
    );

    // console.log(newState);
  };

  render() {
    let overAllSum = 0;
    let individualsum = [];
    this.state.billOfQuantity.map((billdetail) => {
      let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
      return 0;
    });

    return (
      <div className="container">
        <br />

        <h1>💖 Basic Calculator</h1>
        <p>Welcome to the Electron application.</p>

        <Messages ref={this.messagesReferences}></Messages>
        {this.state.billOfQuantity.length > 0 ? (
          <div>
            <button ref={this.buttonCalculatorRef} onClick={this.calculateTotal} className="btn btn-primary ml-2 btn-sm">
              Calculate the overall Perc%
            </button>

            <button onClick={(e) => this.openNewWindow(2)} className="btn btn-primary ml-2 btn-sm">
              Open new window
            </button>

            <button onClick={(e) => this.releaseAllLocks()} className="btn btn-primary ml-2 btn-sm">
              Release All locks
            </button>

            <br />
            <br />
            {/* <nav aria-label="Page navigation example">
              <ul className="pagination">
                {this.state.billOfQuantity.map((d, i) => {
                  return (
                    <li
                      key={i}
                      onClick={() => {
                        this.handlePaging(i);
                      }}
                      className="page-item"
                    >
                      <button className="page-link">{i + 1}</button>
                    </li>
                  );
                })}
              </ul>
            </nav> */}

            <table className="table exceltable" width="">
              <thead>
                <tr>
                  <td>OZ</td>
                  <td>kurztext</td>
                  <td>lv_menge</td>
                  <td>Mengeneinheit</td>
                  <td>EP</td>
                  <td>Festpreis</td>
                  <td>GP</td>
                  <td>PERC</td>
                </tr>
              </thead>
              <tbody>
                <OverAllDetails overAllSum={overAllSum}></OverAllDetails>
              </tbody>

              {this.state.billOfQuantity.map((billdetail, index) => {
                // console.log(billdetail);

                let totalSumOfGp = individualsum[index];
                this.overallGp = this.overallGp + totalSumOfGp;
                let classsHidden = index === 0 ? "" : "d-none";
                return (
                  <tbody ref={(el) => (this[`tbody_${index}`] = el)} key={index}>
                    <LvDetails rowdata={billdetail} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} mainIndex={index}></LvDetails>
                    <TableRows
                      handleDoubleClick={this.handleDoubleClick}
                      socket={socket}
                      ref={(el) => (this[`tableRows_${billdetail.lv}`] = el)}
                      rowdata={billdetail.data}
                      totalSumOfGp={totalSumOfGp}
                      overAllSum={overAllSum}
                      updateInternalValues={this.updateInternalValues}
                      mainIndex={index}
                      checkChangesInRow={this.checkChangesInRow}
                      messagesReference={this.messagesReferences}
                      newRowAdded={this.newRowAdded}
                      levelId={this.levelId}
                    ></TableRows>
                  </tbody>
                );
              })}
            </table>
          </div>
        ) : (
          "Loading Data..."
        )}
      </div>
    );
  }
}

export default App;
