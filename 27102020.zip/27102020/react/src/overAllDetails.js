import React from "react";
import "./App.css";
// import "bootstrap/dist/css/bootstrap.min.css";
import CountUp from "react-countup";
class OverAllDetails extends React.Component {
  render() {
    return (
      <tr className="lvdetail">
        <td contentEditable suppressContentEditableWarning={true}>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div>
            <CountUp end={this.props.overAllSum} />
          </div>
        </td>
        <td>
          <div>100%</div>
        </td>
      </tr>
    );
  }
}

export default OverAllDetails;
