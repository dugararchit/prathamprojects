import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
class TestComponent extends React.Component {
  render() {
    return (
      <p>Test Component</p>
    );
  }
}

export default TestComponent;
