import React from "react";
import "./App.css";
// import "bootstrap/dist/css/bootstrap.min.css";
class LvDetails extends React.Component {
  render() {
    let { rowdata } = this.props;
    return (
      <tr className="lvdetail" onClick={e => alert("archit")}>
        <td >
          <div>{rowdata.lv}</div>
        </td>
        <td>
          <div>{rowdata.text}</div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div></div>
        </td>
        <td>
          <div>{this.props.totalSumOfGp}</div>
        </td>
        <td>
          <div>{((this.props.totalSumOfGp / this.props.overAllSum) * 100).toFixed(2)}%</div>
        </td>
      </tr>
    );
  }
}

export default LvDetails;
