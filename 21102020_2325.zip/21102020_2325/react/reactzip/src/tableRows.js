import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";

import SingleRow from "./singleRow";

class TableRows extends React.Component {
  render() {
    // console.log(this.props.rowdata);
    // let totalSumOfGp = this.props.rowdata.reduce(function (cnt, o) {
    //   return cnt + (parseInt(o.ep) * parseInt(o.lv_menge));
    // }, 0);

    return this.props.rowdata.map((item, i) => {
      return (
        <SingleRow key={i} rowdata={item} totalSumOfGp={this.props.totalSumOfGp} overAllSum={this.props.overAllSum} updateInternalValues={this.props.updateInternalValues} mainIndex={this.props.mainIndex} innerIndex={i} checkChangesInRow={this.props.checkChangesInRow}></SingleRow>
      );
    });
  }
}

export default TableRows;
