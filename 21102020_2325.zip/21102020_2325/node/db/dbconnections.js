let db = require('./connections');

class DB {
  async getConnection() {
    let database = await db.getConnection();
    return database.connection;
  }

  async getRecords(
    table,
    fields,
    where = '',
    whereParams = '',
    others = '',
    fullquery,
  ) {
    let connection = await this.getConnection();

    try {
      return new Promise(async (resolve, reject) => {
        table = '`' + table + '`';

        let sql = `SELECT ${fields} from ${table}`;

        try {
          // console.log(connection.format(sql));
          if (fullquery) {
            sql = fullquery;
          }
          const [
            articleRow,
            articleFields,
          ] = await connection.promise().query(sql, [whereParams]);
          resolve(articleRow);
        } catch (error) {
          reject(error);
        }
      });
    } catch (error) {
      return error;
    } finally {
      connection.release();
    }
  }

  async updateRecords(
    table,
    setParams,
    where,
    values,
    type = 'single',
  ) {
    let connection = await this.getConnection();
    try {
      return new Promise(async (resolve, reject) => {
        table = '`' + table + '`';
        // let sql = `UPDATE ${table} SET ${setParams} = ? where ${where}`;
        if (type == 'single')
          var sql =
            'UPDATE ' +
            table +
            ' SET ' +
            setParams +
            ' where ' +
            where;
        else
          var sql =
            'UPDATE ' +
            table +
            ' SET ' +
            setParams +
            ' = ? where ' +
            where;

        try {
          console.log(connection.format(sql, values));
          const [
            articleRow,
            articleFields,
          ] = await connection.promise().query(sql, values);
          resolve(articleRow);
        } catch (error) {
          reject(error);
        }
      });
    } catch (error) {
      console.log(error);
      return error;
    } finally {
      connection.release();
    }
  }
}

// async function init() {
//   let conn = new DB();
//   let records = await conn.getRecords("billofquantitychild", "*");
//   console.log(records);
// }

// init();

module.exports = DB;

// pool.getConnection(function (err, connection) {
//   if (err) throw err; // not connected!

//   // Use the connection
//   connection.query("SELECT * FROM billofquantitychild", function (error, results, fields) {
//     // When done with the connection, release it.
//     connection.release();

//     if (error) throw error;
//     console.log(results);
//     // Don't use the connection here, it has been returned to the pool.
//   });
// });
