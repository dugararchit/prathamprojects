import { Router } from 'express';
require('../../db/connections');
let DB = require('../../db/dbconnections');
let db = new DB();
const router = Router();
const moment = require('moment');
let socket = require('./index');

router.get('/', async (req, res) => {
  let data = await db.getRecords(
    '',
    '',
    '',
    '',
    '',
    'select * from billofquantityparent as p inner join billofquantitychild as c on c.parent_boq=p.id',
  );
  // console.log(data);
  let mainObj = {};
  data.forEach((element) => {
    let obj = {};
    let lvData = [];
    if (mainObj[element.parent_boq] == undefined) {
      mainObj[element.parent_boq] = {};
      mainObj[element.parent_boq].lv = element.parent_boq;
      mainObj[element.parent_boq].text = element.title;
      mainObj[element.parent_boq].data = [];
      mainObj[element.parent_boq].data.push({
        parent_boq: element.parent_boq,
        oz: element.oz,
        id: element.id,
        kurztext: element.kurztext,
        lv_menge: element.lv_menge,
        mengeneinheit: element.mengeneinheit,
        ep: element.ep,
        is_locked: element.is_locked,
      });
    } else {
      mainObj[element.parent_boq].data.push({
        parent_boq: element.parent_boq,
        oz: element.oz,
        id: element.id,
        kurztext: element.kurztext,
        lv_menge: element.lv_menge,
        mengeneinheit: element.mengeneinheit,
        ep: element.ep,
        is_locked: element.is_locked,
      });
    }
    // console.log(obj);
  });
  let ArrayData = [];
  for (let tmp in mainObj) {
    // console.log(tmp);
    ArrayData.push(mainObj[tmp]);
  }
  return res.send(ArrayData);
});

router.put('/:id/:locked', async (req, res) => {
  console.log(req.params.id);
  let is_locked = req.params.locked == '1' ? 1 : 0;
  let updatedData = await db.updateRecords(
    'billofquantitychild',
    `is_locked=${is_locked}, modified_at='${moment().format(
      'YYYY-MM-DD HH:mm:ss',
    )}'`,
    `id=${req.params.id}`,
  );
  console.log(updatedData);
  return res.send(updatedData);
});

router.get('/releasealllock', async (req, res) => {
  console.log(req.params.id);
  let updatedData = await db.updateRecords(
    'billofquantitychild',
    `is_locked=0`,
    `is_locked=1`,
  );
  console.log(updatedData);
  return res.send(updatedData);
});

router.post('/changedData', async (req, res) => {
  let objectDataArray = req.body;
  objectDataArray.forEach((objectData) => {
    objectData.is_locked = objectData.is_locked.toString();
    objectData.modified_at = moment().format('YYYY-MM-DD HH:mm:ss');
    const columns = Object.keys(objectData);
    const values = Object.values(objectData);

    db.updateRecords(
      'billofquantitychild',
      `${columns.join(' = ? ,')}`,
      `id='${objectData.id}'`,
      values,
      'multiple',
    );
  });
  return res.send({
    success: true,
  });
});

export default router;
