var mysql = require("mysql");
console.log(mysql);
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "erz",
});

connection.connect();

module.exports = connection;

