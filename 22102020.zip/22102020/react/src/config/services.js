import { HOST, boqApiRoute } from "./config";

export let getBoqData = () =>  {
    //==get all data from api
    return new Promise(async (resolve, reject) => {
        try{
            const response = await fetch(`${HOST}/${boqApiRoute}`);
            const boqData = await response.json();
            resolve(boqData);   
        }catch(err){
            console.log("error while fetching data for getApiData");
        }
    })
}

export let releaseAllLocks = () =>  {
    //==Release all locks
    return new Promise(async (resolve, reject) => {
        try{
            const response = await fetch(`${HOST}/${boqApiRoute}/releasealllock`);
            const boqData = await response.json();
            resolve(boqData);   
        }catch(err){
            console.log("error while fetching data for releaseAllLocks");
        }
    })
}

export let handleRowLocking = (id, status) =>  {
    //==releasing individual lock from id
    return new Promise(async (resolve, reject) => {
        try{
            const response = await fetch(`${HOST}/${boqApiRoute}/${id}/${status}`, { method: "PUT" });
            const boqData = await response.json();
            resolve(boqData);   
        }catch(err){
            console.log("error while fetching data for releasingIndividualLock");
        }
    })
}

export let updateRowData = (data) =>  {
    //==releasing individual lock from id
    return new Promise(async (resolve, reject) => {
        try{
            const requestOptions = {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            };
            const response = await fetch(`${HOST}/${boqApiRoute}/updateSingleRecord`, requestOptions)
            const boqData = await response.json();
            resolve(boqData);   
        }catch(err){
            console.log("error while fetching data for releasingIndividualLock");
        }
    })
}


