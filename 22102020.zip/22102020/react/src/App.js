import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import TableRows from "./tableRows";
import LvDetails from "./lvDetails";
import OverAllDetails from "./overAllDetails";
import { HOST } from "./config/config";
import { getBoqData, releaseAllLocks } from "./config/services";
import socketIOClient from "socket.io-client";
import Messages from "./messages";
// import { Button, Collapse } from "react-bootstrap";

const socket = socketIOClient(HOST);

class App extends React.Component {
  constructor(props) {
    super(props);
    this.previousRow = "";
    this.openCollapser = false;
    this.previousRowParentId = "";
    this.newStateAfterChanges = [];
    this.buttonCalculatorRef = React.createRef();
    this.messagesReferences = React.createRef();
    this.is_touched = [];
    this.state = {
      billOfQuantity: [],
      overallGp: 0,
    };
  }

  async componentDidMount() {
    //===fetching all data at the initial state from the database/api
    // fetch(`${HOST}/${boqApiRoute}`)
    //   .then((response) => response.json())
    //   .then((data) => {
    //     console.log(data);

    //     //===older
    //     this.setState({
    //       billOfQuantity: data,
    //     });
    //   });
    
    getBoqData().then(data => {
        this.setState({
          billOfQuantity: data,
        });
    }).catch(err => {
      console.log(err);
    })

    socket.on("calculator", () => {
      console.log("staring calculating");
      // this.buttonCalculatorRef.current.disabled = false;
      this.setState({
        billOfQuantity: this.newStateAfterChanges,
      });
    });

    socket.on("updatedChangedData", (data) => {
      console.log(data);
      let billNewState = this.state.billOfQuantity;
      data.forEach((element) => {
        let mainIndex = billNewState.findIndex((el) => el.lv === element.parent_boq);
        if (mainIndex !== -1) {
          let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === element.id);
          console.log(childIndex);
          billNewState[mainIndex].data[childIndex] = element;

          this.setState({
            billOfQuantity: billNewState,
          });
        }
      });
    });

    socket.on("updatedLockedChanges", ({ rowData }) => {
      console.log(rowData);
      this.buttonCalculatorRef.current.disabled = false;
      // let data = data.rowData;
      let billNewState = this.state.billOfQuantity;
      // data.forEach((element) => {
      let mainIndex = billNewState.findIndex((el) => el.lv === rowData.parent_boq);
      if (mainIndex !== -1) {
        let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === rowData.id);
        console.log(childIndex);
        billNewState[mainIndex].data[childIndex] = rowData;
        let findingChildRef = this[`tableRows_${parseInt(rowData.parent_boq)}`][`singleRowRef_${parseInt(rowData.id)}`];
        console.log(findingChildRef);
        findingChildRef.updateProps(rowData);
        this.newStateAfterChanges = billNewState;
        console.log(this);
      }
      // });
    });

    socket.on("locking", (data) => {
      console.log(data);
      //=======custom table
      let billNewState = this.state.billOfQuantity;
      let mainIndex = billNewState.findIndex((el) => el.lv === data.rowData.parent_boq);
      console.log((this.buttonCalculatorRef.current.disabled = true));
      this.buttonCalculatorRef.current.disabled = true;
      if (mainIndex !== -1) {
        let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === data.rowData.id);
        billNewState[mainIndex].data[childIndex]["is_locked"] = data.rowData.type === "locked" ? "1" : "0";
        let findingChildRef = this[`tableRows_${parseInt(data.rowData.parent_boq)}`][`singleRowRef_${parseInt(data.rowData.id)}`];
        console.log(findingChildRef);
        if (data.type === "locked") {
          data.rowData.is_locked = "1";
        }
        findingChildRef.updateProps(data.rowData);
        this.newStateAfterChanges = billNewState;
      }
    });
  }

  updateInternalValues = (whichLevel, index, whathaschanged, newValue, rowData) => {
    console.log(rowData);
    console.log("updateinternalvalues");
    let newState = JSON.parse(JSON.stringify(this.state.billOfQuantity));
    // newState[whichLevel].data[index] = whathaschanged;
    console.log(newValue);
    console.log(newState[whichLevel].data[index][whathaschanged]);
    newState[whichLevel].data[index][whathaschanged] = newValue;
    console.log(newState[whichLevel].data[index][whathaschanged]);
    // innerData[whathaschanged] = whichvalue;
    // let touchedData = this.is_touched;
    // let alreadyAvailableDataIndex = touchedData.findIndex((ele) => ele.id === innerData.id);
    // if (alreadyAvailableDataIndex !== -1) {
    //   touchedData[alreadyAvailableDataIndex] = innerData;
    // } else {
    //   touchedData = [...touchedData, innerData];
    // }
    // this.is_touched = touchedData;
    this.newStateAfterChanges = newState;
    console.log(this.newStateAfterChanges);
    
    socket.emit("updatedLockedChanges", { rowData });
    console.log(this);
  };


  releaseAllLocks = async () => {
    let releasinglocks = await releaseAllLocks();
    console.log(releasinglocks);
  };

  // sendUpdatedData = () => {
  //   const requestOptions = {
  //     method: "POST",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(this.is_touched),
  //   };
  //   fetch(`${HOST}/${boqApiRoute}/changedData`, requestOptions)
  //     .then((response) => response.json())
  //     .then((data) => {
  //       this.is_touched.forEach((element) => {
  //         let findingChildRef = this[`tableRows_${parseInt(element.parent_boq)}`][`singleRowRef_${parseInt(element.id)}`];
  //         console.log(findingChildRef);
  //         findingChildRef.clearingRowColor();
  //       });
  //       //=====================================

  //       socket.emit("updateddata", this.is_touched);
  //       this.is_touched = [];
  //     });
  // };


  calculateTotal = () => {
    console.log("calculating");
    console.log(this.newStateAfterChanges);
    this.setState({
      billOfQuantity: this.newStateAfterChanges,
    });
    socket.emit("calculator");
  };

  handlePaging = (id) => {
    for (let i = 0; i < this.state.billOfQuantity.length; i++) {
      if (i === id) this[`tbody_${i}`].classList.remove("d-none");
      else this[`tbody_${i}`].classList.add("d-none");
    }
  };

  render() {
    let overAllSum = 0;
    let individualsum = [];
    this.state.billOfQuantity.map((billdetail) => {
      let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
    });

    return (
      <div className="container">
        <br />

        <h1>💖 Basic Calculator</h1>
        <p>Welcome to the Electron application.</p>

        <Messages ref={this.messagesReferences}></Messages>
        {this.state.billOfQuantity.length > 0 ? (
          <div>
            <button onClick={this.releaseAllLocks} className="btn btn-primary btn-sm">
              Release all locks
            </button>

            {/* <button onClick={this.sendUpdatedData} className="btn btn-primary ml-2 btn-sm">
              Calculate your data and send to database
            </button> */}

            <button ref={this.buttonCalculatorRef} onClick={this.calculateTotal} className="btn btn-primary ml-2 btn-sm">
              Calculate
            </button>
            <br />
            <br />
            <nav aria-label="Page navigation example">
              <ul className="pagination">
                {this.state.billOfQuantity.map((d, i) => {
                  return (
                    <li
                      key={i}
                      onClick={() => {
                        this.handlePaging(i);
                      }}
                      className="page-item"
                    >
                      <button className="page-link">{i + 1}</button>
                    </li>
                  );
                })}
              </ul>
            </nav>

            <table className="table exceltable" width="">
              <thead>
                <tr>
                  <td>OZ</td>
                  <td>kurztext</td>
                  <td>lv_menge</td>
                  <td>Mengeneinheit</td>
                  <td>EP</td>
                  <td>Festpreis</td>
                  <td>GP</td>
                  <td>PERC</td>
                </tr>
              </thead>
              <tbody>
                <OverAllDetails overAllSum={overAllSum}></OverAllDetails>
              </tbody>

              {this.state.billOfQuantity.map((billdetail, index) => {
                let totalSumOfGp = individualsum[index];
                this.overallGp = this.overallGp + totalSumOfGp;
                let classsHidden = index === 0 ? "" : "d-none";
                return (
                  <tbody ref={(el) => (this[`tbody_${index}`] = el)} className={classsHidden} key={index}>
                    <LvDetails rowdata={billdetail} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} mainIndex={index}></LvDetails>
                    <TableRows
                      handleDoubleClick={this.handleDoubleClick}
                      socket={socket}
                      ref={(el) => (this[`tableRows_${billdetail.lv}`] = el)}
                      rowdata={billdetail.data}
                      totalSumOfGp={totalSumOfGp}
                      overAllSum={overAllSum}
                      updateInternalValues={this.updateInternalValues}
                      mainIndex={index}
                      checkChangesInRow={this.checkChangesInRow}
                      messagesReference={this.messagesReferences}
                    ></TableRows>
                  </tbody>
                );
              })}
            </table>
          </div>
        ) : (
          "Loading Data..."
        )}
      </div>
    );
  }
}

export default App;
