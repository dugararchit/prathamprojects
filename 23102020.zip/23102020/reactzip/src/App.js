import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import TableRows from "./tableRows";
import LvDetails from "./lvDetails";
import OverAllDetails from "./overAllDetails";

import socketIOClient from "socket.io-client";
const ENDPOINT = "http://localhost:5000";
const socket = socketIOClient(ENDPOINT);
// import { Button, Collapse  } from "react-bootstrap";
class App extends React.Component {
  constructor(props) {
    super(props);
    this.previousRow = "";
    this.previousRowParentId = "";
    this.state = {
      // billOfQuantity: [
      //   {
      //     level: {
      //       lv: "001",
      //       text: "Title A",
      //       gp: 0,
      //       data: [
      //         { oz: "001.00001", kurztext: "Position A00001", lv_menge: "100", mengeneinheit: "m2", ep: "11" },
      //         { oz: "001.00002", kurztext: "Position A00002", lv_menge: "100", mengeneinheit: "m2", ep: "20000" },
      //         { oz: "001.00003", kurztext: "Position A00003", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00004", kurztext: "Position A00004", lv_menge: "100", mengeneinheit: "m2", ep: "13" },
      //         { oz: "001.00005", kurztext: "Position A00005", lv_menge: "100", mengeneinheit: "m2", ep: "11" },
      //         { oz: "001.00006", kurztext: "Position A00006", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00007", kurztext: "Position A00007", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00008", kurztext: "Position A00008", lv_menge: "100", mengeneinheit: "m2", ep: "200" },
      //         { oz: "001.00009", kurztext: "Position A00009", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00010", kurztext: "Position A00010", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00011", kurztext: "Position A00011", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00012", kurztext: "Position A00012", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00013", kurztext: "Position A00013", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00014", kurztext: "Position A00014", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00015", kurztext: "Position A00015", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00016", kurztext: "Position A00016", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00017", kurztext: "Position A00017", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00018", kurztext: "Position A00018", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00019", kurztext: "Position A00019", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00020", kurztext: "Position A00020", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00021", kurztext: "Position A00021", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00022", kurztext: "Position A00022", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00023", kurztext: "Position A00023", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00024", kurztext: "Position A00024", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00025", kurztext: "Position A00025", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00026", kurztext: "Position A00026", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00027", kurztext: "Position A00027", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00028", kurztext: "Position A00028", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00029", kurztext: "Position A00029", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00030", kurztext: "Position A00030", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00031", kurztext: "Position A00031", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00032", kurztext: "Position A00032", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00033", kurztext: "Position A00033", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00034", kurztext: "Position A00034", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00035", kurztext: "Position A00035", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00036", kurztext: "Position A00036", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00037", kurztext: "Position A00037", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00038", kurztext: "Position A00038", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00039", kurztext: "Position A00039", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00040", kurztext: "Position A00040", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00041", kurztext: "Position A00041", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00042", kurztext: "Position A00042", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00043", kurztext: "Position A00043", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00044", kurztext: "Position A00044", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00045", kurztext: "Position A00045", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00046", kurztext: "Position A00046", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00047", kurztext: "Position A00047", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00048", kurztext: "Position A00048", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00049", kurztext: "Position A00049", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "001.00050", kurztext: "Position A00050", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //       ],
      //     },
      //   },
      //   {
      //     level: {
      //       lv: "002",
      //       text: "Title B",
      //       gp: 0,
      //       data: [
      //         { oz: "002.00001", kurztext: "Position B00001", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00002", kurztext: "Position B00002", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00003", kurztext: "Position B00003", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00004", kurztext: "Position B00004", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00005", kurztext: "Position B00005", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00006", kurztext: "Position B00006", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00007", kurztext: "Position B00007", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00008", kurztext: "Position B00008", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00009", kurztext: "Position B00009", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00010", kurztext: "Position B00010", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00011", kurztext: "Position B00011", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00012", kurztext: "Position B00012", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00013", kurztext: "Position B00013", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00014", kurztext: "Position B00014", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00015", kurztext: "Position B00015", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00016", kurztext: "Position B00016", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00017", kurztext: "Position B00017", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00018", kurztext: "Position B00018", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00019", kurztext: "Position B00019", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00020", kurztext: "Position B00020", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00021", kurztext: "Position B00021", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00022", kurztext: "Position B00022", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00023", kurztext: "Position B00023", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00024", kurztext: "Position B00024", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00025", kurztext: "Position B00025", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00026", kurztext: "Position B00026", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00027", kurztext: "Position B00027", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00028", kurztext: "Position B00028", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00029", kurztext: "Position B00029", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00030", kurztext: "Position B00030", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00031", kurztext: "Position B00031", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00032", kurztext: "Position B00032", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00033", kurztext: "Position B00033", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00034", kurztext: "Position B00034", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00035", kurztext: "Position B00035", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00036", kurztext: "Position B00036", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00037", kurztext: "Position B00037", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00038", kurztext: "Position B00038", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00039", kurztext: "Position B00039", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00040", kurztext: "Position B00040", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00041", kurztext: "Position B00041", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00042", kurztext: "Position B00042", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00043", kurztext: "Position B00043", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00044", kurztext: "Position B00044", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00045", kurztext: "Position B00045", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00046", kurztext: "Position B00046", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00047", kurztext: "Position B00047", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00048", kurztext: "Position B00048", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00049", kurztext: "Position B00049", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "002.00050", kurztext: "Position B00050", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //       ],
      //     },
      //   },
      //   {
      //     level: {
      //       lv: "003",
      //       text: "Title C",
      //       gp: 0,
      //       data: [
      //         { oz: "003.00001", kurztext: "Position C00001", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00002", kurztext: "Position C00002", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00003", kurztext: "Position C00003", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00004", kurztext: "Position C00004", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00005", kurztext: "Position C00005", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00006", kurztext: "Position C00006", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00007", kurztext: "Position C00007", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00008", kurztext: "Position C00008", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00009", kurztext: "Position C00009", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00010", kurztext: "Position C00010", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00011", kurztext: "Position C00011", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00012", kurztext: "Position C00012", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00013", kurztext: "Position C00013", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00014", kurztext: "Position C00014", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00015", kurztext: "Position C00015", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00016", kurztext: "Position C00016", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00017", kurztext: "Position C00017", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00018", kurztext: "Position C00018", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00019", kurztext: "Position C00019", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00020", kurztext: "Position C00020", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00021", kurztext: "Position C00021", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00022", kurztext: "Position C00022", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00023", kurztext: "Position C00023", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00024", kurztext: "Position C00024", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00025", kurztext: "Position C00025", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00026", kurztext: "Position C00026", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00027", kurztext: "Position C00027", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00028", kurztext: "Position C00028", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00029", kurztext: "Position C00029", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00030", kurztext: "Position C00030", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00031", kurztext: "Position C00031", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00032", kurztext: "Position C00032", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00033", kurztext: "Position C00033", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00034", kurztext: "Position C00034", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00035", kurztext: "Position C00035", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00036", kurztext: "Position C00036", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00037", kurztext: "Position C00037", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00038", kurztext: "Position C00038", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00039", kurztext: "Position C00039", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00040", kurztext: "Position C00040", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00041", kurztext: "Position C00041", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00042", kurztext: "Position C00042", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00043", kurztext: "Position C00043", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00044", kurztext: "Position C00044", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //         { oz: "003.00045", kurztext: "Position C00045", lv_menge: "100", mengeneinheit: "m2", ep: "10" },
      //       ],
      //     },
      //   },
      // ],

      billOfQuantity: [],
      is_touched: [],
      overallGp: 0,
      open: 0,
    };
  }

  componentDidMount() {
    fetch("http://localhost:5000/boq")
      .then((response) => response.json())
      .then((data) => {
        // console.log(data);
        this.setState({
          billOfQuantity: data,
        });
      });

    socket.on("FromAPI", (data) => {
      console.log(data);
    });

    socket.on("changeInData", (data) => {
      console.log(data);
    });

    socket.on("locking", (data) => {
      // {type: "locked", id: 1, parentId: "1"}
      console.log(data);
      let billNewState = this.state.billOfQuantity;
      let mainIndex = billNewState.findIndex((el) => el.level.lv === data.parentId);
      console.log(mainIndex != -1);
      if (mainIndex !== -1) {
        let childIndex = billNewState[mainIndex].level.data.findIndex((childEl) => childEl.id === data.id);
        console.log(childIndex);
        billNewState[mainIndex].level.data[childIndex]["is_locked"] = data.type === "locked" ? "1" : "0";
        console.log(billNewState);
        this.updateState(billNewState);
      }
    });
  }

  updateState = (newState) => {
    this.setState({
      billOfQuantity: newState,
    });
  };

  updateInternalValues = (whichLevel, index, whathaschanged, whichvalue) => {
    // console.log(whichLevel, index, whichvalue);
    // this.state.billOfQuantity[whichLevel].level.data[index][whathaschanged] = whichvalue;
    let newState = this.state.billOfQuantity;
    newState[whichLevel].level.data[index][whathaschanged] = whichvalue;
    newState[whichLevel].level.data[index]["is_locked"] = 1;
    // console.log(newState[whichLevel].level.data[index]);
    this.setState({
      billOfQuantity: newState,
      is_touched: [...this.state.is_touched, newState[whichLevel].level.data[index]],
    });
  };

  checkChangesInRow = (currentRow, parentid) => {
    // console.log(this.previousRow, currentRow);

    //==releasing the previous row and sent the message that lock has been released
    socket.emit("locking", { type: "locked", id: currentRow, parentId: this.previousRowParentId });
    if (this.previousRow != "" && this.previousRow != currentRow) {
      console.log(`Releasing id ${this.previousRow}`);
      socket.emit("locking", { type: "release", id: this.previousRow, parentId: this.previousRowParentId });
      fetch(`http://localhost:5000/boq/${this.previousRow}/0`, { method: "PUT" })
        .then((response) => response.json())
        .then((data) => {
          console.log(`id released ${this.previousRow}`);
        });
    }
    this.previousRow = currentRow;
    this.previousRowParentId = parentid;
  };

  render() {
    let overAllSum = 0;
    let individualsum = [];
    this.state.billOfQuantity.map((billdetail) => {
      let totalSumOfGp = billdetail.level.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
    });

    return (
      <div className="container">
        <br />
        <h1>💖 Basic Calculator</h1>
        <p>Welcome to the Electron application.</p>

        <table className="exceltable" width="750px">
          <thead>
            <tr>
              <td>OZ</td>
              <td>kurztext</td>
              <td>lv_menge</td>
              <td>Mengeneinheit</td>
              <td>EP</td>
              <td>Festpreis</td>
              <td>GP</td>
              <td>PERC</td>
            </tr>
          </thead>
          <tbody>
            <OverAllDetails overAllSum={overAllSum}></OverAllDetails>
          </tbody>

          {this.state.billOfQuantity.map((billdetail, index) => {
            let totalSumOfGp = individualsum[index];
            this.overallGp = this.overallGp + totalSumOfGp;
            return (
              <tbody key={index}>
                <LvDetails rowdata={billdetail} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} mainIndex={index}></LvDetails>
                <TableRows rowdata={billdetail.level.data} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} updateInternalValues={this.updateInternalValues} mainIndex={index} checkChangesInRow={this.checkChangesInRow}></TableRows>
              </tbody>
            );
          })}
        </table>
      </div>
    );
  }
}

export default App;
