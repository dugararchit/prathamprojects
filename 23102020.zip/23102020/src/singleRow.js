import React from "react";
import "./App.css";
import { AiFillLock } from "react-icons/ai";
import { handleRowLocking, updateRowData } from "./config/services";
let { ipcRenderer } = window.require("electron");
class SingleRow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rowcolor: "",
      updateProps: "0",
    };
  }

  clearingRowColor = () => {
    this.setState({
      rowcolor: "",
    });
  };

  componentDidMount() {}

  handleChange = (element, whathaschanged) => {
    //====introduce one more api to save the data
    console.log(this.props.rowdata);
    let currentValueOfElement = element.currentTarget.textContent.trim();

    this.props.rowdata[whathaschanged] = currentValueOfElement;
    element.currentTarget.contentEditable = false;
    element.currentTarget.suppressContentEditableWarning = true;
    console.log(this.props.rowdata);

    this.setState({
      rowcolor: "",
    });

    handleRowLocking(this.props.rowdata.id, 0)
      .then((data) => {
        console.log(data);
      })
      .catch((err) => {
        console.log(err);
      });

    updateRowData(this.props.rowdata)
      .then((data) => {
        console.log(data);
      })
      .catch((err) => {
        console.log(err);
      });

    this.props.socket.emit("updatedLockedChanges", { rowData: this.props.rowdata });
    this.props.messagesReference.current.showMessage("The current row lock is now Released.");
  };

  updateProps = (rowData) => {
    console.log("entered in single row", rowData);
    this.props.rowdata.ep = rowData.ep;
    this.props.rowdata.lv_menge = rowData.lv_menge;
    this.props.rowdata.is_locked = rowData.is_locked;
    this.setState({
      updateProps: "1",
    });
  };

  doubleClicked = (element, isContEditable) => {
    if (isContEditable) {
      this.setState({
        rowcolor: "lightpink",
      });
      console.log(element);
      console.log(this.props.messagesReference);
      this.props.messagesReference.current.showMessage("The current row is now locked for others, and now you can edit the row ");
      element.currentTarget.contentEditable = isContEditable;
      element.currentTarget.suppressContentEditableWarning = true;
      element.currentTarget.style.outline = "none";

      handleRowLocking(this.props.rowdata.id, 1)
        .then((data) => {
          console.log(data);
        })
        .catch((err) => {
          console.log(err);
        });
      this.props.socket.emit("locking", { type: "locked", rowData: this.props.rowdata });
    }
  };

  keyPress = (event) => {
    //=================stop entering chacters and on enter do blur
    if (event.charCode === 13) {
      event.target.blur();
    }
    if (isNaN(String.fromCharCode(event.which))) {
      event.preventDefault();
    }
  };

  onDragStart = (eve) => {
    console.log(eve);
    console.log(eve.currentTarget);

    console.log(ipcRenderer);
    ipcRenderer.send("dragstart", this.props.rowdata);
  };

  onDragOver = (ele) => {
    ele.preventDefault();
    // console.log(ele);
  };

  onDrop = (ele) => {
    ipcRenderer.on(`draggablevalue`, (event, args) => {
      console.log(this.props.rowdata);
      console.log(args);
      ipcRenderer.removeAllListeners("draggablevalue");
    });
    //ele.preventDefault();
    console.log(ele);
    ele.currentTarget.style.backgroundColor = "yellow";
    // console.log(ele.currentTarget);
    // console.log(this.props);
    // console.log(window);
    ipcRenderer.send("dragstop");
  };

  render() {
    console.log("archit");
    let gp = this.props.rowdata.ep * this.props.rowdata.lv_menge;
    let perc = (gp / this.props.totalSumOfGp) * 100;
    let isContEditable = true;
    if (this.props.rowdata.is_locked.toString() === "1") isContEditable = false;

    // if (this.props.dataCalculated && this.props.dataCalculated === 1) this.setState({ rowColor: "" });
    return (
      // onDragOver={(e) => this.allowDrop(e)} onDragStart={(event) => this.drag(event)} onDragOver={(e) => this.allowDrop(e)} draggable="true"
      <tr
        className="singleRow"
        onDragStart={(event) => this.onDragStart(event)}
        onDragOver={(e) => this.onDragOver(e)}
        onDrop={(e) => {
          this.onDrop(e);
        }}
        draggable="true"
        id={this.props.rowdata.id}
        style={{ backgroundColor: this.state.rowcolor }}
      >
        <td>
          <div>
            {!isContEditable ? <AiFillLock></AiFillLock> : ""}
            {this.props.rowdata.oz}
          </div>
        </td>
        <td>
          <div>{this.props.rowdata.kurztext}</div>
        </td>
        <td>
          <div onKeyPress={this.keyPress.bind(this)} onDoubleClick={(e) => this.doubleClicked(e, isContEditable)} onBlur={(e) => this.handleChange(e, "lv_menge")} style={{ backgroundColor: "light" }} className="lv_menge">
            {this.props.rowdata.lv_menge}
          </div>
        </td>
        <td>
          <div>{this.props.rowdata.mengeneinheit}</div>
        </td>
        <td>
          <div onKeyPress={this.keyPress.bind(this)} onDoubleClick={(e) => this.doubleClicked(e, isContEditable)} onBlur={(e) => this.handleChange(e, "ep")} className="ep">
            {this.props.rowdata.ep}
          </div>
        </td>
        <td>
          <div contentEditable={isContEditable} suppressContentEditableWarning={true}>
            {this.props.rowdata.festpreis}
          </div>
        </td>
        <td>
          <div>{gp}</div>
        </td>
        <td>
          <div>{perc.toFixed(2)}%</div>
        </td>
      </tr>
    );
  }
}

export default SingleRow;
