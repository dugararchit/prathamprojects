import React from "react";
// import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import TableRows from "./tableRows";
import LvDetails from "./lvDetails";
import OverAllDetails from "./overAllDetails";
import { HOST, boqApiRoute } from "./config/config";
import socketIOClient from "socket.io-client";
// import "mdbreact/dist/css/mdb.css";
import ReactDataSheet from "react-datasheet";
// import "react-select/dist/react-select.css";
import "react-datasheet/lib/react-datasheet.css";

const ENDPOINT = "http://localhost:5000";
const socket = socketIOClient(ENDPOINT);

// import { Button, Collapse  } from "react-bootstrap";
class App extends React.Component {
  constructor(props) {
    super(props);
    // console.log(this);
    this.previousRow = "";
    this.previousRowParentId = "";
    this.is_touched = [];
    this.state = {
      billOfQuantity: [],
      overallGp: 0,
      grid: [
        [
          { value: "OZ", readOnly: true },
          { value: "kurztext", readOnly: true },
          { value: "lv_menge", readOnly: true },
          { value: "Mengeneinheit", readOnly: true },
          { value: "EP", readOnly: true },
          { value: "Festpreis", readOnly: true },
          { value: "GP", readOnly: true },
          { value: "PERC", readOnly: true },
        ],
        // [{ readOnly: true, value: 1 }, { value: 1 }, { value: 3 }, { value: 3 }, { value: 3 }, { readOnly: true, value: 1 }, { readOnly: true, value: 1 }, { readOnly: true, value: 1 }],
      ],
    };
  }

  componentDidMount() {
    //===fetching all data at the initial state from the database/api
    fetch(`${HOST}/${boqApiRoute}`)
      .then((response) => response.json())
      .then((data) => {
        // console.log(data);

        let GridArray = [];
        data.forEach((el) => {
          let arrayData = [];
          GridArray.push([
            { value: el.lv, readOnly: true },
            { value: el.text, readOnly: true },
            { value: "", readOnly: true },
            { value: "", readOnly: true },
            { value: "", readOnly: true },
            { value: "", readOnly: true },
            { value: "", readOnly: true },
            { value: "", readOnly: true },
          ]);

          // var obj = { value: el.text };

          // console.log(arrayData);
          el.data.forEach((innerData) => {
            var innerArray = [{ value: innerData.oz }, { value: innerData.kurztext }, { value: innerData.lv_menge }, { value: innerData.mengeneinheit }, { value: innerData.ep }, { value: innerData.mengeneinheit }, { value: "" }, { value: "" }];
            // console.log(innerArray);
            // arrayData = [...arrayData, ...innerArray];
            // arrayData.push(innerArray);
            GridArray.push(innerArray);
          });
        });
        // console.log(GridArray);

        this.setState({
          billOfQuantity: data,
          grid: [...this.state.grid, ...GridArray],
        });
      });

    socket.on("updatedChangedData", (data) => {
      console.log(data);
      let billNewState = this.state.billOfQuantity;
      data.forEach((element) => {
        let mainIndex = billNewState.findIndex((el) => el.lv === element.parent_boq);
        if (mainIndex !== -1) {
          let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === element.id);
          console.log(childIndex);
          billNewState[mainIndex].data[childIndex] = element;

          this.setState({
            billOfQuantity: billNewState,
          });
        }
      });
    });

    socket.on("locking", (data) => {
      let billNewState = this.state.billOfQuantity;
      let mainIndex = billNewState.findIndex((el) => el.lv === data.parentId);
      if (mainIndex !== -1) {
        let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === data.id);
        billNewState[mainIndex].data[childIndex]["is_locked"] = data.type === "locked" ? "1" : "0";
        this.setState({
          billOfQuantity: billNewState,
        });
      }
    });
  }

  updateInternalValues = (whichLevel, index, whathaschanged, whichvalue) => {
    console.log("updateinternalvalues");
    let newState = this.state.billOfQuantity;
    let innerData = newState[whichLevel].data[index];
    innerData[whathaschanged] = whichvalue;
    let touchedData = this.is_touched;
    let alreadyAvailableDataIndex = touchedData.findIndex((ele) => ele.id === innerData.id);
    if (alreadyAvailableDataIndex !== -1) {
      touchedData[alreadyAvailableDataIndex] = innerData;
    } else {
      touchedData = [...touchedData, innerData];
    }
    this.is_touched = touchedData;
    this.setState({
      billOfQuantity: newState,
    });
  };

  checkChangesInRow = (currentRow, parentid, lockcurrent) => {
    //==releasing the previous row and sent the message that lock has been released
    if (lockcurrent) socket.emit("locking", { type: "locked", id: currentRow, parentId: parentid });
    else socket.emit("locking", { type: "release", id: currentRow, parentId: parentid });
    if (this.previousRow !== "" && this.previousRow !== currentRow) {
      console.log(`Releasing id ${this.previousRow}`);
      socket.emit("locking", { type: "release", id: this.previousRow, parentId: this.previousRowParentId });
      fetch(`${HOST}/${boqApiRoute}/${this.previousRow}/0`, { method: "PUT" })
        .then((response) => response.json())
        .then((data) => {
          console.log(`id released ${this.previousRow}`);
        });
    }
    this.previousRow = currentRow;
    this.previousRowParentId = parentid;
  };

  releaseAllLocks = () => {
    fetch(`${HOST}/${boqApiRoute}/releasealllock`, { method: "GET" })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      });
  };

  sendUpdatedData = () => {
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(this.is_touched),
    };
    fetch(`${HOST}/${boqApiRoute}/changedData`, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        //====clearin all element color
        //==method1
        // var allElement = document.getElementsByClassName("singleRow");
        // for (var i = 0; i < allElement.length; i++) {
        //   allElement[i].style.backgroundColor = "";
        // }

        //===method2
        //==creating a reference for every child element
        this.is_touched.forEach((element) => {
          let findingChildRef = this[`tableRows_${parseInt(element.parent_boq)}`][`singleRowRef_${parseInt(element.id)}`];
          console.log(findingChildRef);
          findingChildRef.clearingRowColor();
        });
        //=====================================

        socket.emit("updateddata", this.is_touched);
        this.is_touched = [];
        // this.setState({
        //   is_touched: [],
        // });
      });
  };

  render() {
    let overAllSum = 0;
    let individualsum = [];
    this.state.billOfQuantity.map((billdetail) => {
      let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
    });

    return (
      <div className="container">
        <br />
        <h1>💖 Basic Calculator</h1>
        <p>Welcome to the Electron application.</p>
        <ReactDataSheet
          data={this.state.grid}
          onCellsChanged={(changes) => {
            const grid = this.state.grid.map((row) => [...row]);
            changes.forEach(({ cell, row, col, value }) => {
              grid[row][col] = { ...grid[row][col], value };
            });
            this.setState({ grid });
          }}
          valueRenderer={(cell) => cell.value}
          dataRenderer={(cell) => cell.expr}
          // onCellsChanged={this.onCellsChanged}
        />

        {this.state.billOfQuantity.length > 0 ? (
          <div>
            <button onClick={this.releaseAllLocks} className="btn btn-primary btn-sm">
              Release all locks
            </button>

            <button onClick={this.sendUpdatedData} className="btn btn-primary ml-2 btn-sm">
              Calculate your data and send to database
            </button>
            <br />
            <br />

            <table className="table exceltable" width="">
              <thead>
                <tr>
                  <td>OZ</td>
                  <td>kurztext</td>
                  <td>lv_menge</td>
                  <td>Mengeneinheit</td>
                  <td>EP</td>
                  <td>Festpreis</td>
                  <td>GP</td>
                  <td>PERC</td>
                </tr>
              </thead>
              <tbody>
                <OverAllDetails overAllSum={overAllSum}></OverAllDetails>
              </tbody>

              {this.state.billOfQuantity.map((billdetail, index) => {
                let totalSumOfGp = individualsum[index];
                this.overallGp = this.overallGp + totalSumOfGp;
                return (
                  <tbody key={index}>
                    <LvDetails rowdata={billdetail} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} mainIndex={index}></LvDetails>
                    <TableRows ref={(el) => (this[`tableRows_${billdetail.lv}`] = el)} rowdata={billdetail.data} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} updateInternalValues={this.updateInternalValues} mainIndex={index} checkChangesInRow={this.checkChangesInRow}></TableRows>
                  </tbody>
                );
              })}
            </table>
          </div>
        ) : (
          ""
        )}
      </div>
    );
  }
}

export default App;
