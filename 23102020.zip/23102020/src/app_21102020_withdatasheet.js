import React from "react";
// import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import TableRows from "./tableRows";
import LvDetails from "./lvDetails";
import OverAllDetails from "./overAllDetails";
import { HOST, boqApiRoute } from "./config/config";
import socketIOClient from "socket.io-client";
// import "mdbreact/dist/css/mdb.css";
import ReactDataSheet from "react-datasheet";
// import "react-select/dist/react-select.css";
import "react-datasheet/lib/react-datasheet.css";
import { AiFillCaretRight, AiFillRest, AiOutlineStrikethrough } from "react-icons/ai";

const ENDPOINT = "http://localhost:5000";
const socket = socketIOClient(ENDPOINT);

// import { Button, Collapse  } from "react-bootstrap";
class App extends React.Component {
  constructor(props) {
    super(props);
    // console.log(this);
    this.previousRow = "";
    this.previousRowParentId = "";
    this.is_touched = [];
    this.state = {
      billOfQuantity: [],
      overallGp: 0,
      grid: [
        // [{ readOnly: true, value: 1 }, { value: 1 }, { value: 3 }, { value: 3 }, { value: 3 }, { readOnly: true, value: 1 }, { readOnly: true, value: 1 }, { readOnly: true, value: 1 }],
      ],
    };
  }

  generateGrid = (data) => {
    let overAllSum = 0;
    let individualsum = [];
    data.map((billdetail) => {
      let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
    });

    let GridArray = [
      [
        { value: "OZ", readOnly: true },
        { value: "kurztext", readOnly: true },
        { value: "lv_menge", readOnly: true },
        { value: "Mengeneinheit", readOnly: true },
        { value: "EP", readOnly: true },
        { value: "Festpreis", readOnly: true },
        { value: "GP", readOnly: true },
        { value: "PERC", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
      ],
      [
        { value: "LV", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: overAllSum, readOnly: true },
        { value: "100%", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
      ],
    ];

    data.forEach((el, index) => {
      let totalSumOfGp = individualsum[index];

      GridArray.push([
        { value: el.lv, readOnly: true },
        { value: el.text, readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: totalSumOfGp, readOnly: true },
        { value: ((totalSumOfGp / overAllSum) * 100).toFixed(2), readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
        { value: "", readOnly: true },
      ]);
      el.data.forEach((innerData) => {
        let gp = innerData.lv_menge * innerData.ep;
        let perc = (gp / totalSumOfGp) * 100;
        let isLocked = innerData.is_locked ? "Locked" : "";
        var innerArray = [
          { key: "oz", value: innerData.oz, disableEvents: true },
          { key: "kurztext", value: innerData.kurztext, disableEvents: true },
          { key: "lv_menge", value: innerData.lv_menge, disableEvents: innerData.is_locked ? true : false },
          { key: "mengeneinheit", value: innerData.mengeneinheit, disableEvents: true },
          { key: "ep", value: innerData.ep, disableEvents: true },
          { key: "festpreis", value: innerData.festpreis, disableEvents: true },
          { key: "gp", value: gp, disableEvents: true },
          { key: "perc", value: perc.toFixed(2), disableEvents: true },
          { key: "is_locked", value: innerData.is_locked ? "Locked" : "", disableEvents: true },
          { key: "parent_boq", value: innerData.parent_boq, disableEvents: true },
          { key: "id", value: innerData.id, disableEvents: true },
        ];
        GridArray.push(innerArray);
      });
    });
    return GridArray;
  };

  componentDidMount() {
    //===fetching all data at the initial state from the database/api
    fetch(`${HOST}/${boqApiRoute}`)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        let GridArray = this.generateGrid(data);
        //===older
        this.setState({
          billOfQuantity: data,
          grid: GridArray,
        });
      });

    socket.on("updatedChangedData", (data) => {
      console.log(data);
      let billNewState = this.state.billOfQuantity;
      data.forEach((element) => {
        let mainIndex = billNewState.findIndex((el) => el.lv === element.parent_boq);
        if (mainIndex !== -1) {
          let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === element.id);
          console.log(childIndex);
          billNewState[mainIndex].data[childIndex] = element;

          this.setState({
            billOfQuantity: billNewState,
          });
        }
      });
    });

    socket.on("locking", (data) => {
      //==datasheet table
      const grid = this.state.grid.map((row) => [...row]);
      console.log(data);
      console.log(grid[data.row]);
      let lockedIndex = grid[data.row].findIndex((el) => el.key === "is_locked");
      let lv_mengeIndex = grid[data.row].findIndex((el) => el.key === "lv_menge");
      let epIndex = grid[data.row].findIndex((el) => el.key === "ep");
      let gpIndex = grid[data.row].findIndex((el) => el.key === "gp");
      if (data.type === "locked") {
        grid[data.row][lockedIndex]["value"] = "locked";
        grid[data.row][lv_mengeIndex]["readOnly"] = true;
        grid[data.row][epIndex]["readOnly"] = true;
      } else if (data.type === "release") {
        grid[data.row][lockedIndex]["value"] = "";
        grid[data.row][lv_mengeIndex]["readOnly"] = false;
        grid[data.row][epIndex]["readOnly"] = false;
        grid[data.row][epIndex]["value"] = data.data[epIndex]["value"];
        grid[data.row][lv_mengeIndex]["value"] = data.data[lv_mengeIndex]["value"];
        grid[data.row][gpIndex]["value"] = data.data[gpIndex]["value"];
      }
      this.setState({ grid });

      //=======custom table
      let billNewState = this.state.billOfQuantity;
      let mainIndex = billNewState.findIndex((el) => el.lv === data.parentId);
      if (mainIndex !== -1) {
        let childIndex = billNewState[mainIndex].data.findIndex((childEl) => childEl.id === data.id);
        billNewState[mainIndex].data[childIndex]["is_locked"] = data.type === "locked" ? "1" : "0";
        this.setState({
          billOfQuantity: billNewState,
        });
      }
    });
  }

  updateInternalValues = (whichLevel, index, whathaschanged, whichvalue) => {
    console.log("updateinternalvalues");
    let newState = this.state.billOfQuantity;
    let innerData = newState[whichLevel].data[index];
    innerData[whathaschanged] = whichvalue;
    let touchedData = this.is_touched;
    let alreadyAvailableDataIndex = touchedData.findIndex((ele) => ele.id === innerData.id);
    if (alreadyAvailableDataIndex !== -1) {
      touchedData[alreadyAvailableDataIndex] = innerData;
    } else {
      touchedData = [...touchedData, innerData];
    }
    this.is_touched = touchedData;
    this.setState({
      billOfQuantity: newState,
    });
  };

  checkChangesInRow = (currentRow, parentid, lockcurrent) => {
    //==releasing the previous row and sent the message that lock has been released
    if (lockcurrent) socket.emit("locking", { type: "locked", id: currentRow, parentId: parentid });
    else socket.emit("locking", { type: "release", id: currentRow, parentId: parentid });
    if (this.previousRow !== "" && this.previousRow !== currentRow) {
      console.log(`Releasing id ${this.previousRow}`);
      socket.emit("locking", { type: "release", id: this.previousRow, parentId: this.previousRowParentId });
      fetch(`${HOST}/${boqApiRoute}/${this.previousRow}/0`, { method: "PUT" })
        .then((response) => response.json())
        .then((data) => {
          console.log(`id released ${this.previousRow}`);
        });
    }
    this.previousRow = currentRow;
    this.previousRowParentId = parentid;
  };

  releaseAllLocks = () => {
    fetch(`${HOST}/${boqApiRoute}/releasealllock`, { method: "GET" })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      });
  };

  sendUpdatedData = () => {
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(this.is_touched),
    };
    fetch(`${HOST}/${boqApiRoute}/changedData`, requestOptions)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        //====clearin all element color
        //==method1
        // var allElement = document.getElementsByClassName("singleRow");
        // for (var i = 0; i < allElement.length; i++) {
        //   allElement[i].style.backgroundColor = "";
        // }

        //===method2
        //==creating a reference for every child element
        this.is_touched.forEach((element) => {
          let findingChildRef = this[`tableRows_${parseInt(element.parent_boq)}`][`singleRowRef_${parseInt(element.id)}`];
          console.log(findingChildRef);
          findingChildRef.clearingRowColor();
        });
        //=====================================

        socket.emit("updateddata", this.is_touched);
        this.is_touched = [];
        // this.setState({
        //   is_touched: [],
        // });
      });
  };

  handleDataEditor = (editorProps) => {
    console.log(editorProps);
    return <input type="text" value={editorProps.value}></input>;
  };

  refreshdatasheet = () => {
    const grid = this.state.grid.map((row) => [...row]);
    let billOfQuantityState = this.state.billOfQuantity;
    console.log(grid);

    // let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
    //   return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
    // }, 0);
    // let individualSum = {};
    //==calculating the total new sum
    grid.filter((element) => {
      let innerData = element.find((e) => e.key === "id");
      if (innerData) {
        // let gpIndex = parseInt(element.findIndex((data) => data.key === "gp"));
        // let parentBoqIndex = parseInt(element.findIndex((data) => data.key === "parent_boq"));
        let parentBoqValue = element.find((data) => data.key === "parent_boq").value;
        let lvValue = element.find((data) => data.key === "lv_menge").value;
        let epValue = element.find((data) => data.key === "ep").value;
        // console.log(parentBoqValue);
        let parentFinder = billOfQuantityState.find((parentData) => parentData.lv === parentBoqValue);

        let valueFinder = parentFinder.data.find((gpData) => gpData.id === parseInt(innerData.value));
        // console.log(valueFinder);
        valueFinder.ep = epValue;
        valueFinder.lv_menge = lvValue;

        // if (!individualSum[element[parentBoqIndex].value]) {
        //   individualSum[element[parentBoqIndex].value] = 0;
        // }
        // individualSum[element[parentBoqIndex].value] += element[gpIndex].value;
      }
    });
    console.log(billOfQuantityState);
    let GridArray = this.generateGrid(billOfQuantityState);

    this.setState({
      grid: GridArray,
    });

    // this.setState({
    // //   grid: [],
    // // });
    // // this.setState({
    // //   grid: grid,
    // // });

    // let individualSum = {};
    //==calculating the total new sum
    // grid.filter((element) => {
    //   let innerData = element.find((e) => e.key === "id");
    //   if (innerData) {
    //     // let gpIndex = parseInt(element.findIndex((data) => data.key === "gp"));
    //     // let parentBoqIndex = parseInt(element.findIndex((data) => data.key === "parent_boq"));
    //     let parentBoqValue = element.find((data) => data.key === "parent_boq").value;
    //     let lvValue = element.find((data) => data.key === "lv_menge").value;
    //     let epValue = element.find((data) => data.key === "ep").value;
    //     // console.log(parentBoqValue);
    //     let parentFinder = billOfQuantityState.find((parentData) => parentData.lv === parentBoqValue);

    //     let valueFinder = parentFinder.data.find((gpData) => gpData.id === parseInt(innerData.value));
    //     // console.log(valueFinder);
    //     valueFinder.ep = epValue;
    //     valueFinder.lv_menge = lvValue;

    //     // if (!individualSum[element[parentBoqIndex].value]) {
    //     //   individualSum[element[parentBoqIndex].value] = 0;
    //     // }
    //     // individualSum[element[parentBoqIndex].value] += element[gpIndex].value;
    //   }
    // });
  };
  render() {
    let overAllSum = 0;
    let individualsum = [];
    this.state.billOfQuantity.map((billdetail) => {
      let totalSumOfGp = billdetail.data.reduce(function (cnt, o) {
        return cnt + parseInt(o.ep) * parseInt(o.lv_menge);
      }, 0);
      individualsum.push(totalSumOfGp);
      overAllSum += totalSumOfGp;
    });

    return (
      <div className="container">
        {/* <button onClick={this.refreshdatasheet} className="btn btn-primary btn-sm">
          Calculate
        </button> */}
        <br />
        <h1>💖 Basic Calculator</h1>
        <p>Welcome to the Electron application.</p>
        {/* <ReactDataSheet
          data={this.state.grid}
          onCellsChanged={(changes) => {
            const grid = this.state.grid.map((row) => [...row]);

            changes.forEach(({ cell, row, col, value }) => {
              let gpIndex = grid[row].findIndex((el) => el.key === "gp");
              let lv_mengeIndex = grid[row].findIndex((el) => el.key === "lv_menge");
              let epIndex = grid[row].findIndex((el) => el.key === "ep");
              let idIndex = grid[row].findIndex((el) => el.key === "id");
              let parentBoqIndex = grid[row].findIndex((el) => el.key === "parent_boq");
              console.log(grid[row]);
              console.log(row, col, value);
              console.log(grid[row][col]);
              console.log({ ...grid[row][col], value });
              grid[row][col] = { ...grid[row][col], value };
              let total = grid[row][lv_mengeIndex].value * grid[row][epIndex].value;
              // alert(total);
              grid[row][gpIndex] = { ...grid[row][gpIndex], value: total };
              // grid[row][epIndex] = { ...grid[row][epIndex], readOnly: true };
              // grid[row][lv_mengeIndex] = { ...grid[row][lv_mengeIndex], readOnly: true };
              fetch(`${HOST}/${boqApiRoute}/${grid[row][idIndex].value}/0`, { method: "PUT" })
                .then((response) => response.json())
                .then((data) => {
                  console.log(`id released ${grid[row][idIndex].value}`);
                });
              socket.emit("locking", { type: "release", id: grid[row][idIndex].value, parentId: grid[row][parentBoqIndex].value, data: grid[row], row: row });
            });
            this.setState({ grid });
          }}
          onSelect={(cell) => {
            console.log(cell);
          }}
          // dataEditor={this.handleDataEditor}
          cellRenderer={(props) => {
            let { onDoubleClick, children, className, onMouseOver, row, col, onMouseDown, selected, editing } = props;

            //==hiding parent boq
            if (col === 9 || col === 10) return <td></td>;

            return (
              <td
                // onClick={() => {
                //   const grid = this.state.grid.map((row) => [...row]);
                //   console.log(grid[row]);
                //   grid[row][col].disableEvents = false;
                //   this.setState({
                //     grid: grid,
                //   });
                // }}
                onDoubleClick={(e) => {
                  console.log(selected, editing);
                  onDoubleClick();
                  console.log(row, col);
                  const grid = this.state.grid.map((row) => [...row]);
                  console.log(grid[row]);
                  // grid[row][col].disableEvents = false;
                  // this.setState({
                  //   grid: grid,
                  // });
                  let idIndex = grid[row].findIndex((el) => el.key === "id");
                  let epIndex = grid[row].findIndex((el) => el.key === "ep");
                  let lvIndex = grid[row].findIndex((el) => el.key === "lv_menge");
                  if (epIndex === col) {
                    //alert("Value editing is EP");
                    console.log(grid[row][col]);
                  } else {
                    //alert("Value editing is LV");
                  }

                  let parentBoqIndex = grid[row].findIndex((el) => el.key === "parent_boq");
                  fetch(`${HOST}/${boqApiRoute}/${grid[row][idIndex].value}/1`, { method: "PUT" })
                    .then((response) => response.json())
                    .then((data) => {
                      console.log(`id locked ${grid[row][idIndex].value}`);
                    });
                  socket.emit("locking", { type: "locked", id: grid[row][idIndex].value, parentId: grid[row][parentBoqIndex].value, data: grid[row], row: row });
                }}
                onMouseOver={onMouseOver}
                className={className}
                onMouseDown={onMouseDown}
              >
                {children}
              </td>
            );
          }}
          valueRenderer={(cell) => cell.value}
          dataRenderer={(cell) => cell.expr}
          // onCellsChanged={this.onCellsChanged}
        /> */}

        {this.state.billOfQuantity.length > 0 ? (
          <div>
            <button onClick={this.releaseAllLocks} className="btn btn-primary btn-sm">
              Release all locks
            </button>

            <button onClick={this.sendUpdatedData} className="btn btn-primary ml-2 btn-sm">
              Calculate your data and send to database
            </button>
            <br />
            <br />

            <table className="table exceltable" width="">
              <thead>
                <tr>
                  <td>OZ</td>
                  <td>kurztext</td>
                  <td>lv_menge</td>
                  <td>Mengeneinheit</td>
                  <td>EP</td>
                  <td>Festpreis</td>
                  <td>GP</td>
                  <td>PERC</td>
                </tr>
              </thead>
              <tbody>
                <OverAllDetails overAllSum={overAllSum}></OverAllDetails>
              </tbody>

              {this.state.billOfQuantity.map((billdetail, index) => {
                let totalSumOfGp = individualsum[index];
                this.overallGp = this.overallGp + totalSumOfGp;
                return (
                  <tbody key={index}>
                    <LvDetails rowdata={billdetail} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} mainIndex={index}></LvDetails>
                    <TableRows ref={(el) => (this[`tableRows_${billdetail.lv}`] = el)} rowdata={billdetail.data} totalSumOfGp={totalSumOfGp} overAllSum={overAllSum} updateInternalValues={this.updateInternalValues} mainIndex={index} checkChangesInRow={this.checkChangesInRow}></TableRows>
                  </tbody>
                );
              })}
            </table>
          </div>
        ) : (
          ""
        )}
      </div>
    );
  }
}

export default App;
