const { app, BrowserWindow, ipcMain, ipcRenderer } = require("electron");

var isDev = require("electron-is-dev");
const path = require("path");
let draggableElement = "";
let mainWindow;
isDev = true;
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 800,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      enableRemoteModule: true,
    },
  });

  const startUrl = isDev ? "http://localhost:3000" : `file://${path.join(__dirname, "../build/index.html")}`;

  mainWindow.loadURL(startUrl);
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.on("ready", createWindow);

ipcMain.on("asynchronous-message", (event, arg) => {
  console.log("heyyyy", arg); // prints "heyyyy ping"

  const win = new BrowserWindow({
    width: 800,
    height: 500,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      enableRemoteModule: true,
    },
    parent: mainWindow,
  });

  win.loadURL("http://localhost:3000");
  win.once("ready-to-show", () => win.show());
});

ipcMain.on("dragstart", (event, args) => {
  // ipcRenderer.send("draggeddrop", args);
  // event.sender.reply("draggeddrop", args);
  draggableElement = args;
});

ipcMain.on("dragstop", (event, args) => {
  // ipcRenderer.send("draggeddrop", args);
  event.sender.send("draggablevalue", draggableElement);
  draggableElement = "";
});
