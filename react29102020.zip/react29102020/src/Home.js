import React from "react";
import App from "./App";
import { BrowserRouter as Router, HashRouter, Switch, Route } from "react-router-dom";
class Home extends React.Component {
  render() {
    return (
      <Router>
        <HashRouter>
          <Route path="/:id?" render={(props) => <App {...props} />} />
        </HashRouter>
      </Router>
    );
  }
}

export default Home;
