let HOST = "http://localhost:5000";
let boqApiRoute = "boq";

module.exports = {
  HOST,
  boqApiRoute,
};
