import React from "react";

class Messages extends React.Component {
  constructor() {
    super();
    this.state = {
      message: "",
      opacity: 0,
    };
  }

  showMessage = (message) => {
    this.setState({
      message: message,
      opacity: 1,
    });
    setTimeout(() => {
      this.setState({
        message: "",
        opacity: 0,
      });
    }, 4500);
  };
  render() {
    return (
      <div className="alert alert-success" style={{ position: "fixed", opacity: this.state.opacity }} role="alert">
        {this.state.message}
      </div>
    );
  }
}

export default Messages;
